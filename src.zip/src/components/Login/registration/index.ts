/**
 * Экспорт модуля регистрации
 */

export { useReg } from './useReg'
export { default as RegistrationForm } from './RegistrationForm'
export type * from './useReg'