/**
 * Экспорт всех компонентов модуля Cargos
 */

export { CargoCard } from './CargoCard';
export { CargoForm } from './CargoForm';
export { CargosList } from './CargosList';
