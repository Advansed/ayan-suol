// src/components/ServerConnectionGuard/index.ts

export { ServerConnectionGuard } from './ServerConnectionGuard';