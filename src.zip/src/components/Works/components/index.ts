/**
 * Экспорт всех компонентов модуля Works
 */

export { WorkCard } from './WorkCard';
export { WorksList } from './WorksList';
export { WorkView } from './WorkView';
export { WorkOffer } from './WorkOffer';
export { WorkArchive } from './WorkArchive';